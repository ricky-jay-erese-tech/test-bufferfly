class UserManager:
    def __init__(self):
        self.users = []  # List to store user data

    def add_user(self, username, email, role, admin_code=None):
        # Check if username is unique
        if any(user["username"] == username for user in self.users):
            raise ValueError("Error: Username already exists")

        # Validate email format (basic check)
        if "@" not in email or "." not in email.split("@")[-1]:
            raise ValueError("Invalid email address")

        # Validate role
        if role not in ["admin", "editor", "viewer"]:
            raise ValueError("Error: Invalid role")

        # Check for admin_code if role is admin
        if role == "admin":
            if not admin_code or not isinstance(admin_code, str) or len(admin_code) < 4:
                raise ValueError("Admin code is required and must be at least 4 characters long")

        # Add user to the list
        self.users.append({"username": username, "email": email, "role": role})
        print(f"User {username} added successfully!")

    def get_users_by_role(self, role):
        # Validate role input
        if role not in ["admin", "editor", "viewer"]:
            raise ValueError("Error: Invalid role")

        # Filter users by role
        return [user for user in self.users if user["role"] == role]


# Example Usage
if __name__ == "__main__":
    manager = UserManager()

    try:
        # Add users
        manager.add_user("john", "john@example.com", "editor")
        manager.add_user("alice", "alice@example.com", "admin", admin_code="1234")
        manager.add_user("bob", "bob@example.com", "viewer")
        
        # Try adding a duplicate username
        manager.add_user("john", "duplicate@example.com", "viewer")  # This will raise an error
    except ValueError as e:
        print(e)

    try:
        # Try adding a user with invalid email
        manager.add_user("invalid", "invalid-email", "editor")
    except ValueError as e:
        print(e)

    try:
        # Get users by role
        editors = manager.get_users_by_role("editor")
        print("Editors:", editors)

        # Try an invalid role
        invalid_users = manager.get_users_by_role("manager")  # This will raise an error
    except ValueError as e:
        print(e)
